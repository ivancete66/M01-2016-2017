#!/bin/bash 

clear

echo $USERNAME
echo $PATH
echo $HOME
