#!/bin/bash

clear

"Soy el Operario y estoy en :" echo $HOME

